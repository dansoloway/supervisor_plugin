<div>
    <div class="sidebar-buttons">
        <a class="sidebar-button assistant-bold <?php echo is_page(SUPERVISOR_UPDATES) ? 'supervisor_button_active' : ''; ?>" href="<?php echo get_the_permalink(SUPERVISOR_UPDATES); ?>">עדכונים</a>
        <a class="sidebar-button assistant-bold <?php echo is_page(SUPERVISOR_INTRO_TEXT) ? 'supervisor_button_active' : ''; ?>" href="<?php echo get_the_permalink(SUPERVISOR_INTRO_TEXT); ?>">פיקוח על שירותים חברתיים</a>
        <a class="sidebar-button assistant-bold <?php echo is_page(SUPERVISOR_BIB_CATS) ? 'supervisor_button_active' : ''; ?>" href="<?php echo get_the_permalink(SUPERVISOR_BIB_CATS); ?>">רשימה ביבליוגרפית נבחרת</a>
        <a class="sidebar-button assistant-bold <?php echo is_page(SUPERVISOR_ORGS) ? 'supervisor_button_active' : ''; ?>" href="<?php echo get_the_permalink(SUPERVISOR_ORGS); ?>">ארגוני פיקוח מן העולם</a>
    </div>
</div>