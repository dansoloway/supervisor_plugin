<div class="supervisor-search">
    <input type="text" placeholder="חיפוש" class="supervisor-search-bar">
    <button class="search-button">
        <svg class="search-icon" width="24" height="24" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="13" cy="13" r="9" stroke="white" stroke-width="4"/>
            <line x1="19" y1="19" x2="28" y2="28" stroke="white" stroke-width="4"/>
        </svg>
    </button>
</div>

<br>
<br>