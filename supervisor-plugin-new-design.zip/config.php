<?php

define("PLUGIN_ROOT", "/www/brookdalejdcorg_480/public/wp-content/plugins/supervisor-plugin/");

define("SUPERVISOR_HOME", '27886');
define("SUPERVISOR_BIB_CATS", '27899');
define("SUPERVISOR_UPDATES", '27906');
define("SUPERVISOR_ORGS", '27928');

// Single Content Pages - using content-supervisor.php template
define("SUPERVISOR_ABOUT", '27908');
define("SUPERVISOR_CONTACT", '27912');
define("SUPERVISOR_INTRO_TEXT", '27901');

?>