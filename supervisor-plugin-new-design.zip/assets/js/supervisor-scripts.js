jQuery(document).ready(function ($) {
    console.log("Supervisor plugin script loaded!");
});